<p align="center">
  <a href="https://github.com/DenverCoder1/readme-typing-svg"><img src="https://readme-typing-svg.herokuapp.com?size=21&color=F7E7E5&background=F8000000&lines=Advanced+Reports;Report+The+Bad+People&center=true&width=500&height=50"></a>
   </p>
   
## Game Supported
- CS:GO

## Custom Features
- Set your open report resons in the cfg file



## ConVars
- sm_advreports_discord - Should we print to the discord server, reports? (0 off, 1 on).
- sm_advreports_webhook - Sets where the webhook should send.

## Player Commands
- /calladmin - Opens the player report menu.

## Admin Commands
- /reports - Opens the admin menu for, reported players.
- /purge - Purges the reports list after X days.

## How to Install
- Donwload AdvancedReports.smx and put into /csgo/addons/sourcemod/plugins
- Configure settings by editing /cfg/sourcemod/advreasons.cfg

## Updates

| Version | Change-Log         |
| ------- | ------------------ |
| 1.0.0   | Added plugin to GitHub 5/4/22 |
